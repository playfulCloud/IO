package mondryptaszeknasosnie.Controller;

public class Chatbot {

	/**
	 * 
	 * @param question
	 */
	public void answer(String question) {
		// TODO - implement Chatbot.answer
		throw new UnsupportedOperationException();
	}

}