package mondryptaszeknasosnie.Controller;

import mondryptaszeknasosnie.Model.*;

public class ExternalPaymentProcessor implements PaymentProcessor {

	/**
	 * 
	 * @param payment
	 */
	public void pay(Payment payment) {
		// TODO - implement ExternalPaymentProcessor.pay
		throw new UnsupportedOperationException();
	}

}