package mondryptaszeknasosnie.Controller;

import mondryptaszeknasosnie.Model.*;

public class InternalPaymentProcessor implements PaymentProcessor {

	/**
	 * 
	 * @param payment
	 */
	public void pay(Payment payment) {
		// TODO - implement InternalPaymentProcessor.pay
		throw new UnsupportedOperationException();
	}

}