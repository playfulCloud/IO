package mondryptaszeknasosnie.Controller;

public class LoginDataValidator implements Validator {

	/**
	 * 
	 * @param obj
	 */
	public boolean validate(LoginData obj) {
		// TODO - implement LoginDataValidator.validate
		throw new UnsupportedOperationException();
	}

}