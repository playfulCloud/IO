package mondryptaszeknasosnie.Controller;

import mondryptaszeknasosnie.Model.*;

public class PaymentValidator {

	/**
	 * 
	 * @param obj
	 */
	public boolean validate(Payment obj) {
		// TODO - implement PaymentValidator.validate
		throw new UnsupportedOperationException();
	}

}