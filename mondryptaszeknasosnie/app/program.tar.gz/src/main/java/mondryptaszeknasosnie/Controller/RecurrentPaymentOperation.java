package mondryptaszeknasosnie.Controller;

public enum RecurrentPaymentOperation {
	Delete,
	Update,
	Create,
	Select
}