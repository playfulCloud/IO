package mondryptaszeknasosnie.Controller;

public class RecurrentPaymentValidator implements Validator {

	/**
	 * 
	 * @param obj
	 */
	public boolean validate(RecurrentPayment obj) {
		// TODO - implement RecurrentPaymentValidator.validate
		throw new UnsupportedOperationException();
	}

}