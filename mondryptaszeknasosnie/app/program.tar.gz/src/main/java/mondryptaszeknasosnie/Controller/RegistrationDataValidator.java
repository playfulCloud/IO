package mondryptaszeknasosnie.Controller;

public class RegistrationDataValidator implements Validator {

	/**
	 * 
	 * @param obj
	 */
	public boolean validate(RegistrationData obj) {
		// TODO - implement RegistrationDataValidator.validate
		throw new UnsupportedOperationException();
	}

}