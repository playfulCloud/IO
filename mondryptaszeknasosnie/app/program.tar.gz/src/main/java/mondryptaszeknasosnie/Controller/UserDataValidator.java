package mondryptaszeknasosnie.Controller;

public class UserDataValidator implements Validator {

	/**
	 * 
	 * @param obj
	 */
	public boolean validate(UserData obj) {
		// TODO - implement UserDataValidator.validate
		throw new UnsupportedOperationException();
	}

}