package mondryptaszeknasosnie.Controller;

public interface Validator {

	/**
	 * 
	 * @param obj
	 */
	boolean validate(Object obj);

}