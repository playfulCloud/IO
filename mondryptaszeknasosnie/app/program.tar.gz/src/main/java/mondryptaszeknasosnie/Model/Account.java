package mondryptaszeknasosnie.Model;

public interface Account {

	abstract AccountNumber address();

	abstract Currency currency();

}