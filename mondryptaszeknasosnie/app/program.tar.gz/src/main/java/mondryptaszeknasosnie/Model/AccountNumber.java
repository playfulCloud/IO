package mondryptaszeknasosnie.Model;

public class AccountNumber {

	private int[] data;

}