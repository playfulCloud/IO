package mondryptaszeknasosnie.Model;

public enum Currency {
	PLN,
	USD,
	EUR
}