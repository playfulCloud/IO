package mondryptaszeknasosnie.Model;

public class ExternalBankAccount implements Account {

	public AccountNumber adress;

	public AccountNumber getAddress() {
		// TODO - implement ExternalBankAccount.getAddress
		throw new UnsupportedOperationException();
	}

	public Currency currency() {
		// TODO - implement ExternalBankAccount.currency
		throw new UnsupportedOperationException();
	}

}