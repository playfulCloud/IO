package mondryptaszeknasosnie.Model;

public class IBADBM extends DBManager {

	/**
	 * 
	 * @param obj
	 */
	public IternalBankAccount findByLoginData(loginData obj) {
		// TODO - implement a.findByLoginData
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param key
	 */
	public boolean delete(int key) {
		// TODO - implement a.delete
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param element
	 */
	public boolean insert(InternalBankAccount element) {
		// TODO - implement a.insert
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param key
	 * @param obj
	 */
	public boolean update(InternalBankAccount key, int obj) {
		// TODO - implement a.update
		throw new UnsupportedOperationException();
	}

	public List<InternalBankAccount> select() {
		// TODO - implement a.select
		throw new UnsupportedOperationException();
	}

}