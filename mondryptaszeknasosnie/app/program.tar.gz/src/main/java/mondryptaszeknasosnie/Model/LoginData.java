package mondryptaszeknasosnie.Model;

public class LoginData {

	public String twoFAData;
	public UserData userData;

}