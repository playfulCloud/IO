package mondryptaszeknasosnie.Model;

public class Payment {

	public String title;
	public Date date;
	public int amount;
	public Account sender;
	Account reciever;
	public Currency currency;

}