package mondryptaszeknasosnie.Model;

public class PaymentDBManager extends DBManager {

	/**
	 * 
	 * @param key
	 */
	public boolean delete(int key) {
		// TODO - implement PaymentDBManager.delete
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param element
	 */
	public boolean insert(RecurrentPayment element) {
		// TODO - implement PaymentDBManager.insert
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param key
	 * @param obj
	 */
	public boolean update(int key, Payment obj) {
		// TODO - implement PaymentDBManager.update
		throw new UnsupportedOperationException();
	}

	public List<Payment> select() {
		// TODO - implement PaymentDBManager.select
		throw new UnsupportedOperationException();
	}

}