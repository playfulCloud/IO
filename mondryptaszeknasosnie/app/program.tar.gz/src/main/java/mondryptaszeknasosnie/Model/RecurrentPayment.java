package mondryptaszeknasosnie.Model;

public class RecurrentPayment {

	public Period period;
	public Date firstPayment;
	public Payment template;

	/**
	 * 
	 * @param date
	 */
	public boolean between(Date date) {
		// TODO - implement RecurrentPayment.between
		throw new UnsupportedOperationException();
	}

}