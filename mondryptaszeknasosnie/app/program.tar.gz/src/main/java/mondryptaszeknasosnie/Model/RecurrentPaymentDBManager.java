package mondryptaszeknasosnie.Model;

public class RecurrentPaymentDBManager extends DBManager {

	/**
	 * 
	 * @param key
	 */
	public boolean delete(int key) {
		// TODO - implement RecurrentPaymentDBManager.delete
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param element
	 */
	public boolean insert(RecurrentPayment element) {
		// TODO - implement RecurrentPaymentDBManager.insert
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param key
	 * @param obj
	 */
	public boolean update(int key, RecurrentPayment obj) {
		// TODO - implement RecurrentPaymentDBManager.update
		throw new UnsupportedOperationException();
	}

	public List<RecurrentPayment> select() {
		// TODO - implement RecurrentPaymentDBManager.select
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param element
	 */
	public boolean insert(RecurrentPayment element) {
		// TODO - implement RecurrentPaymentDBManager.insert
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param key
	 * @param obj
	 */
	public boolean update(int key, RecurrentPayment obj) {
		// TODO - implement RecurrentPaymentDBManager.update
		throw new UnsupportedOperationException();
	}

}