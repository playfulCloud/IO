package mondryptaszeknasosnie.Model;

public class RegistrationData {

	public String name;
	public String surname;
	public String PESEL;
	public String IDNumber;
	public String mailAdress;
	public Date birthDate;
	public UserData userData;

}