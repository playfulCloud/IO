package mondryptaszeknasosnie.Model;

public abstract class UserData {

	protected String login;
	protected String password;

}